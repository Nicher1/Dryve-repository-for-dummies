import setuptools

setuptools.setup(
    name="Dryve D1 Script",
    version="1.0.0",
    author="Nichlas Overgaard Laugesen, Elias Thomassen Dam",
    description="Dryve D1 script created by 2 undergraduate robotic students of Aalborg University",
    packages=["dryveD1"],
    url="https://github.com/Nicher1/Dryve-repository-for-dummies.git",
    licence="Mozilla Public License",
    keywords='robotics DryveD1 Python Script',
    classifiers=[
        'Development Status :: 5 - Stable',
        'Intended Audience :: Developers/Robotic students at AAU Create',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: Mozilla Public License',
        'programming Language :: Python :: 3.11',
    ],
    project_urls={
        'Documentation': 'https://github.com/Nicher1/Dryve-repository-for-dummies',
        'Source': 'https://github.com/Nicher1/Dryve-repository-for-dummies',
        'Tracker': 'https://github.com/Nicher1/Dryve-repository-for-dummies/issues',
    },
    install_requires=['socket'],
    python_requires='>=3.6',
    package_data={
        'Guide': ['How to control the Dryve D1 over Python.pdf'],
    },
)
